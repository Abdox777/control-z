
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <windows.h>

#define CONSOLE_WIDTH 230
#define MAX_NAME_LENGTH 50
#define MAX_MENU_ITEMS 50
#define MAX_STAFF 10
#define MAX_ABSENT_DAY 25




typedef struct  {
char name[MAX_NAME_LENGTH];
int price;
int category; //1 food 2 drinks 3 desserts 4 snacks
char design[100];
int color ;
int quantity;
} menuitem;

typedef struct {
    char name[50];
    int absentdays;
    float salary;
    int password;
} Staff;

typedef struct {
char username[MAX_NAME_LENGTH];
char email[MAX_NAME_LENGTH];
char password[MAX_NAME_LENGTH];
} user;

menuitem menu[MAX_MENU_ITEMS] = {
    {"Pizza", 75.0, 1, "food_pizza.txt", 6}, {"Burger", 60.0, 1, "food_burger.txt", 0}, {"chickn", 50.0, 1, "food_chicken.txt", 0}, {"beef", 25.0, 1,"food_beef.txt", 0},
    {"Pepsi", 20.0, 2, "drinks_pepsi.txt", 1}, {"Water", 10.0, 2, "drinks_water.txt", 9}, {"lamon juice", 30.0, 2, "drinks_lamon_juice.txt", 6}, {"coffee cup", 25.0, 2, "drinks_coffee_cup.txt", 0},
    {"blueberry Cheesecake", 40.0, 3, "desserts_cheesecake.txt", 5}, {"Ice cream", 35.0, 3, "desserts_ice_cream.txt", 5}, {"Cookies & milk ", 25.0, 3, "desserts_cookies&milk.txt", 0}, {"waffle", 30.0, 3, "desserts_waffle.txt", 0},
    {"Fries", 30.0, 4, "snacks_fries.txt", 6}, {"Nachos", 45.0, 4, "snacks_nachos.txt", 6}, {"Nuggets", 55.0, 4, "snacks_nuggets.txt", 6}, {"donut", 40.0, 4, "snacks_donut.txt", 0}
};
int menucount = 16;
int categorycount =4;

menuitem cart[MAX_MENU_ITEMS];
int cartcount = 0;


Staff staff[MAX_STAFF] = {
     {"Abdulrahman", 10, 3000, 1234},
     {"Azzam", 24, 200, 1234}, {"Majed", 5, 4000, 1234}, {"Nour", 0, 5000, 1234}
};

int staffCount = 4;

float totalSales = 0;



void clearscreen(){
system("cls");
system("color F0");
}




void centerprint(char text[],int color){
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsole, 240+color);
    int length = strlen(text);
    int spaces = (CONSOLE_WIDTH-length)/2;
    printf("%*s%s",spaces,"",text);
}

void rightprint(char text[],int color){
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsole, 240+color);
    int length = strlen(text);
    int spaces = (CONSOLE_WIDTH-length);
    printf("%*s%s",spaces,"",text);
}

void place1print(char text[],int color){
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsole, 240+color);
    int length = strlen(text);
    int spaces = (CONSOLE_WIDTH-length)/5;
    printf("%*s%s",spaces,"",text);
}

int wrongans(int *choise) {
    char buffer[100];
    fgets(buffer, sizeof(buffer), stdin);
    buffer[strcspn(buffer, "\n")] = 0;
    for (int i = 0; buffer[i]; i++) {
        if (!isdigit(buffer[i])) {
            centerprint("    Invalid input! Please enter numbers only.\n", 4);
            Sleep(700);
            return 1;
        }
    }

    *choise = atoi(buffer);
    return 0;
}


void centerbutton(char text[],int color){
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsole, 240+color);
    int length = strlen(text);
    int spaces = (CONSOLE_WIDTH-length)/2;
    int starlen = length+3;
    printf("%*s+",spaces,"");
    for(int i = 0;i<=starlen;i++){
        printf("=");
    }
    printf("+\n");
    printf("%*s|  %s  |",spaces,"",text);
    printf("\n%*s+",spaces,"");
    for(int i = 0;i<=starlen;i++){
        printf("=");
    }
    printf("+\n\n");
}

void design(char filename[],int color){
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsole, 240+color);
    FILE *pf = fopen(filename,"r");
    char buffer[255];
    while(fgets(buffer,255,pf) != NULL)
    {
    centerprint(buffer,color);
    }
    printf("\n");
 }

 void rightdesign(char filename[],int color){
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsole, 240+color);
    FILE *pf = fopen(filename,"r");
    char buffer[255];
    while(fgets(buffer,255,pf) != NULL)
    {
        rightprint(buffer,color);
    }
    printf("\n");
 }
int max_id = 0;

void max_idf(char file_name[]) {
    int n = 0;
    FILE *pf = fopen(file_name, "r");
    if (pf == NULL) {
        printf("error opening file x.txt to know max_id.\n");
        return;
    }

    char buffer[220];
    while (fgets(buffer, sizeof(buffer), pf) != NULL) {
        n++;
    }
    fclose(pf);
    max_id = n;
}
char read_output[220] ={0};

int read_s_data(char file_name[], int id, int max_id){
    FILE *pf = fopen(file_name, "r");
        if(pf == NULL){
            printf("error opning file wanted to read.txt");
            return 1;
        }
    for(int i=0;i<max_id ;i++){
        char buffer [220] ={""};
        char read_output[220];
        if(i == id){
            fgets(read_output, sizeof(read_output), pf);
        }
        else {
            fgets(buffer, sizeof(buffer), pf);
        }
    }
    fclose(pf);
    return 0;
}
int read_d_data(char file_name[], int id, int max_id){
    FILE *pf = fopen(file_name, "r");
        if(pf == NULL){
            printf("error opning file wanted to read.txt");
            return 1;
        }
    for(int i=0;i<max_id ;i++){
        char buffer[] ={""};
        int read_output;
        if(i == id){
            fgets(read_output, sizeof(read_output), pf);
        }
        else {
            fgets(buffer, sizeof(buffer), pf);
        }
    }
    fclose(pf);
    return 0;
}

void file_print(char file_name[],int max_id){
    for(int i=0; i < max_id; i++){
        char buffer[220];
        int buffer1 =0;
        float buffer2 =0;
        char read_output[220];
        sprintf(buffer,"%s_names.txt", file_name);
        read_s_data(buffer, i+1, max_id);
        char namea = read_output[0];
        sprintf(buffer,"%s_colors.txt", file_name);
        read_d_data(buffer, i+1, max_id);
        int colora =  read_output[0];
        sprintf(buffer,"%s_prices.txt", file_name);
        read_d_data(buffer, i+1, max_id);
        int pricea = read_output;
        sprintf(buffer,"%s_location.txt", file_name);
        read_s_data(buffer, i+1, max_id);
        char locationa = read_output[0];
        centerbutton(namea, colora);
        centerprint(pricea, colora);
        design(locationa, colora);
    }
}

void firstscreen();

void screens(int choise){
    clearscreen();
    design("home_menu.txt", 0);
        if(choise == 1){
            max_idf("food_names.txt");
           file_print("food", max_id);


        }
        centerbutton("0.    Back     ",4);
        centerprint("      Select an option : ",0);

}

void cartscreen(){
    while(1){
    int total;
    clearscreen();
    design("cart1.txt", 0);

printf("\n\n");
char buffer[100];
if(cartcount == 0){
    centerprint("Your Cart Is Empty",4);
    sleep(7);
    clearscreen();
    firstscreen();
}else{
for(int i =0;i<cartcount;i++){
     sprintf(buffer," (%d) %d x %s = %d$\n",i+1,cart[i].quantity,cart[i].name,cart[i].price*cart[i].quantity);
     centerprint(buffer,0);
     total += cart[i].price*cart[i].quantity;
}
char totalmoney[100];
sprintf(totalmoney,"Total : %d$",total);
centerprint(totalmoney,0);
}
printf("\n");

centerbutton("0. Back",4);
centerbutton("99. Remove Item",4);
centerprint("      Select an option : ",0);
int choise;
if(wrongans(&choise) ==1)continue;
   if(choise == 0) {
        firstscreen();
   }else if(choise == 99){
   centerprint("Select Item Number :",4);
   int remove;
   if(wrongans(&remove) ==1)continue;
   if (remove <= 0 || remove > cartcount) {
        centerprint("    Invalid item number!\n", 4);
        Sleep(700);
        continue;
   }
remove--;
for (int i = remove; i < cartcount - 1; i++) {
        cart[i] = cart[i + 1];
    }
    cartcount--;
    centerprint("    Item removed successfully.\n", 2);
    Sleep(700);
    continue;

    }else {centerprint("    Invalid Choice !\n", 4); Sleep(700);}
    }
}

void checkoutscreen(){
        while(1){
            int total;
            char address[220];
            int ensure;
            int back_now;
            clearscreen();
            design("checkout1.txt", 0);
            char buffer[100];
            if(cartcount == 0){
                centerprint("Nothing ):",4);
                sleep(7);
                clearscreen();
                firstscreen();
            }else{
                for(int i =0;i<cartcount;i++){
                    sprintf(buffer," (%d) %d x %s = %d$\n",i+1,cart[i].quantity,cart[i].name,cart[i].price*cart[i].quantity);
                    centerprint(buffer,0);
                    total += cart[i].price*cart[i].quantity;
                }
                char totalmoney[100];
                sprintf(totalmoney,"Total : %d$",total);
                centerprint(totalmoney,0);
                centerprint("enter your address:", 0);
                scanf("%s", &address);
                centerprint("enter 1 to ensure the process:", 0);
                scanf("%d", &ensure);
                centerprint("thank you for your order ", 0);
                centerprint("the order will arrives in half an hour", 0);
                design("thank_you.txt", 4);
                design("heart.txt", 4);
                centerprint("enter 0 to back", 0);
                scanf("%d", &back_now);
                if(back_now == 0) firstscreen();
                design("thank_you.txt", 4);
                design("heart.txt", 4);
            }
            printf("\n");
            exit(0);
        }
}
void Boss_screen(){
    int total;
    int back_now;
        char buffer[100];
        clearscreen();
        design("boss.txt", 0);
        sprintf(buffer,"Today's sales: %d \n", total);
        centerprint(buffer,0);
        centerprint("last month sales: 53450$\n", 0);
        centerprint("last month Restaurant expenses and workers' salaries: 36000$\n", 0);
        centerprint("last month profits: 17450$\n", 0);
        centerprint("Staff Summary:\n", 0);
        for (int i = 0; i <staffCount; i++) {
            sprintf(buffer, "%s - working days: %d, Salary: %.2f$, password: %f\n\n",
                staff[i].name,
                25 - staff[i].absentdays,
                staff[i].salary,
                staff[i].password);
            centerbutton(buffer, 0);
        }
        centerbutton("to back enter 0:",4);
        scanf("%d", &back_now);
        if(back_now == 0) firstscreen();

}
void staff_screen(){

    while(1){
        int staff_number;
        int staff_password;
        clearscreen();
        design("staff.txt", 0);
        printf("\n");
        centerprint("1. Abdulrahman\n", 0);
        centerprint("2. Azzam\n", 0);
        centerprint("3. Majed\n", 0);
        centerprint("4. Nour\n", 0);
        centerprint("Select staff Number :",0);
        scanf("%d", &staff_number);
        centerprint("Select staff password :",0);
        scanf("%d", &staff_password);
        if(staff_number<5 & staff_number>0 & staff_password == staff[staff_number-1].password){
            clearscreen();
            char buffer[100];
            sprintf(buffer,"welcome %s \n",staff[staff_number-1].name);
            centerprint(buffer,0);
            sprintf(buffer,"last month you absent: %d \n ", staff[staff_number-1].absentdays);
            centerprint(buffer,0);
            sprintf(buffer,"and you salary: %.2f$ \n", staff[staff_number-1].salary);
            centerprint(buffer,0);
            centerprint("to know you salary for this month enter absent days(0-25):\n ", 0);
            float absent_days;
            scanf("%f", &absent_days);
            if (absent_days >= 0 && absent_days <= MAX_ABSENT_DAY) {
                sprintf(buffer, "your salary for this month:%.2f$ ", (MAX_ABSENT_DAY - absent_days) * 200);
                centerprint(buffer, 0);
                sleep(10);
                clearscreen();
                firstscreen();
                }
            else {
                centerprint("  Invalid Choice ! Please enter a value between 0 and 25.\n", 4);
                sleep(5);
            }
            }
        else{

            centerprint("    you are not working here!!!\n", 4);
            sleep(5);
        }
    }
}
void mode(){
    while(1){
        int mode_choise;
        clearscreen();
        design("mode.txt", 0);
        printf("\n\n");
        centerbutton("1. Boss mode", 0);
        centerbutton("2. staff mode", 0);
        centerbutton("0. back to customer mode\n", 0);
        centerprint("Select mode Number :",2);
        scanf("%d", &mode_choise);
        if(mode_choise == 1){
            Boss_screen();
        }
        else if(mode_choise == 2){
            staff_screen();
        }
        else if(mode_choise == 0){
            firstscreen();
        }
        else{
            Sleep(700);
            continue;
        }
    }
}
void firstscreen(){
   int choise;

        while (1) {
            clearscreen();
            design("home_home.txt", 0);
            design("food&drinks.txt", 6);
            design("desserts&snaks.txt", 5);
            design("cart&settings.txt", 2);
            centerbutton("select:",0);
            rightdesign("arrow.txt",4);
            if(wrongans(&choise) ==1)continue;


            switch(choise){
                case 1: screens(choise);
                case 2: screens(choise);
                case 3: screens(choise);
                case 4: screens(choise);
                case 5: cartscreen();
                case 6: checkoutscreen();
                case 7: mode();
                case 8: exit(0);
                default:
                    centerprint("    Invalid Choice !\n", 4);
                    Sleep(700);
                              }
        }
}




int main(){

    firstscreen();
    return 1;
}//control+z
