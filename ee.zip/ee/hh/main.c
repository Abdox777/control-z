#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <windows.h>

#define CONSOLE_WIDTH 100
#define MAX_NAME_LENGTH 50
#define MAX_MENU_ITEMS 50
#define MAX_STAFF 10
#define MAX_ABSENT_DAY 25


void clearscreen(){
system("cls");
system("color F0");
}



void centerprint(char text[],int color){
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsole, 240+color);
    int length = strlen(text);
    int spaces = (CONSOLE_WIDTH-length)/2;
    printf("%*s%s",spaces,"",text);
}

int wrongans(int *choise) {
    char buffer[100];
    fgets(buffer, sizeof(buffer), stdin);
    buffer[strcspn(buffer, "\n")] = 0;
    for (int i = 0; buffer[i]; i++) {
        if (!isdigit(buffer[i])) {
            centerprint("    Invalid input! Please enter numbers only.\n", 4);
            Sleep(700);
            return 1;
        }
    }

    *choise = atoi(buffer);
    return 0;
}


void centerbutton(char text[],int color){
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsole, 240+color);
    int length = strlen(text);
    int spaces = (CONSOLE_WIDTH-length)/2;
    int starlen = length+3;
    printf("%*s+",spaces,"");
    for(int i = 0;i<=starlen;i++){
        printf("=");
    }
    printf("+\n");
    printf("%*s|  %s  |",spaces,"",text);
    printf("\n%*s+",spaces,"");
    for(int i = 0;i<=starlen;i++){
        printf("=");
    }
    printf("+\n\n");
}

void design(char filename[],int color){
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsole, 240+color);
    FILE *pf = fopen(filename,"r");
    char buffer[255];
    while(fgets(buffer,255,pf) != NULL)
    {
    centerprint(buffer,color);
    }
    printf("\n");
 }

int max_id = 0;

void max_idf(char file_name[]) {
    int n = 0;
    FILE *pf = fopen(file_name, "r");
    if (pf == NULL) {
        printf("error opening file x.txt to know max_id.\n");
        return;
    }

    char buffer[220];
    while (fgets(buffer, sizeof(buffer), pf) != NULL) {
        n++;
    }
    fclose(pf);
    max_id = n;
}
char read_output[220] ={0};

int read_s_data(char file_name[], int id, int max_id){
    FILE *pf = fopen(file_name, "r");
        if(pf == NULL){
            printf("error opning file wanted to read.txt");
            return 1;
        }
    for(int i=0;i<max_id ;i++){
        char buffer [220] ={""};
        char read_output[220];
        if(i == id){
            fgets(read_output, sizeof(read_output), pf);
        }
        else {
            fgets(buffer, sizeof(buffer), pf);
        }
    }
    fclose(pf);
    return 0;
}
int read_d_data(char file_name[], int id, int max_id){
    FILE *pf = fopen(file_name, "r");
        if(pf == NULL){
            printf("error opning file wanted to read.txt");
            return 1;
        }
    for(int i=0;i<max_id ;i++){
        char buffer[] ={""};
        int read_output;
        if(i == id){
            fgets(read_output, sizeof(read_output), pf);
        }
        else {
            fgets(buffer, sizeof(buffer), pf);
        }
    }
    fclose(pf);
    return 0;
}

void file_print(char file_name[],int max_id){
    for(int i=0; i < max_id; i++){
        char buffer[220];
        int buffer1 =0;
        float buffer2 =0;
        char read_output[220];
        sprintf(buffer,"%s_names.txt", file_name);
        read_s_data(buffer, i+1, max_id);
        char namea = read_output[0];
        sprintf(buffer,"%s_colors.txt", file_name);
        read_d_data(buffer, i+1, max_id);
        int colora =  read_output[0];
        sprintf(buffer,"%s_prices.txt", file_name);
        read_d_data(buffer, i+1, max_id);
        int pricea = read_output;
        sprintf(buffer,"%s_location.txt", file_name);
        read_s_data(buffer, i+1, max_id);
        char locationa = read_output[0];
        centerbutton(namea, colora);
        centerprint(pricea, colora);
        design(locationa, colora);
    }
}

void main(){
    max_idf("food_names.txt");
    file_print("food", max_id);



}
